This are the files from the django-allauth example
pretty much as-is, except for some visual tweaks
and use of a different bootstrap form renderer.
