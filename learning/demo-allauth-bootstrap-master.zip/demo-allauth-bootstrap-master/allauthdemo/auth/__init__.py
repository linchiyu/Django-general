# See https://docs.djangoproject.com/en/1.7/ref/applications/#for-application-authors
default_app_config = 'allauthdemo.auth.apps.AllAuthDemoAuthAppConfig'
