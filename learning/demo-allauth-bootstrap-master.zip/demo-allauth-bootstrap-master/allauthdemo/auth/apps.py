from django.apps import AppConfig


class AllAuthDemoAuthAppConfig(AppConfig):
    label = "allauthdemo_auth"
    name = "allauthdemo.auth"
    verbose_name = "AllAuthDemo Auth"
